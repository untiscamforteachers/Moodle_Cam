# Moodle_Cam
Moodle_Cam TODO:
in Zip packen https://stackoverflow.com/questions/15968883/how-to-zip-a-folder-itself-using-java Kamera implementiern https://developer.android.com/guide/topics/media/camera Bilder auf bestimmte Auflösung croppen